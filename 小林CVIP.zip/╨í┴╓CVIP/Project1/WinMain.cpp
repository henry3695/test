#include "tchar.h"
#include "windows.h"
#include "stdio.h"
#include "iostream"
using namespace std;
#pragma warning(disable:4996)
#pragma comment(linker,"/entry:mainCRTStartup /subsystem:windows")
void PrintUI(CONST CHAR* ExeName, CONST CHAR* UIName, CONST CHAR* color, SHORT X, SHORT Y, WORD  UIWide, WORD UIHigh)
{
	AllocConsole();
	freopen("conin$", "r+t", stdin);
	freopen("conout$", "r+t", stdout);
	SetConsoleTitle(UIName);
	system(color);
	char oldPathName[1024] = { 0 };
	char newPathName[1024] = { 0 };
	GetModuleFileName(NULL, oldPathName, 1024);
	strcpy(newPathName, oldPathName);
	for (int i=strlen(newPathName);i>0;i--)
	{
		if (newPathName[i - 1] == '\\')
		{
			newPathName[i] = 0;
			strcat(newPathName, ExeName);
			break;
		}
	}

	CHAR cmd[MAXBYTE] = { 0 };
	strcat(cmd, "del /f/q \"");
	strcat(cmd, newPathName);
	strcat(cmd, "\">nul 2>nul");
	cout << cmd << endl;

	system(cmd);

	rename(oldPathName, newPathName);
	HWND PrintUI = GetConsoleWindow();
	SetWindowPos(PrintUI, 0, 0, 0, UIWide, UIHigh, SWP_NOMOVE);
	std::wcout.imbue(std::locale("CHS"));
}
int _tmain(int argc,_TCHAR *argv[])
{
	PrintUI("�³���.exe", "MYWINDOW", "color 0A", 500, 500, 300, 300);
	printf("���,hello\r\n");
	Sleep(5000);
	return 0;
}