#include "stdafx.h"
#include "TSpan.h"


TSpan::TSpan()
{
	m_dtTick = ::GetTickCount();
}


TSpan::~TSpan()
{
}

void TSpan::Begin()
{
	m_dtTick = ::GetTickCount();
}

DWORD TSpan::SpanSec()
{
	return (::GetTickCount() - m_dtTick) / 1000;
}

DWORD TSpan::SpanMillSec()
{
	return (::GetTickCount() - m_dtTick) ;
}
