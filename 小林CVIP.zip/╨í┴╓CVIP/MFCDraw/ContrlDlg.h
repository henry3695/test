#pragma once
#include "TSpan.h"
#include "vector"
using namespace std;

#define CHESS_CX 37
#define CHESS_CY 32

typedef struct  _stChessPixel
{
	CString sValue;
	COLORREF Pixels[CHESS_CX][CHESS_CY];
	vector<POINT> vecZM;
}ChessPixel;
// CContrlDlg �Ի���
class CContrlDlg : public CDialog
{
	DECLARE_DYNAMIC(CContrlDlg)

public:
	CContrlDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CContrlDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_CTRL };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonTest();


	CWnd* m_pMainWnd;
	CFont m_cfont;
	virtual BOOL OnInitDialog();


	CWnd* m_pStatic1;
	CWnd* m_pStatic2;
	CWnd* m_pStatic3;
	afx_msg void OnBnClickedCheckShow();
	afx_msg void OnBnClickedCheckNick();
	afx_msg void OnBnClickedButtonExit();
	afx_msg void OnBnClickedCheckFull();


	CRect m_rectGameDlg;


	BOOL CompareArea(CDC* pChessDC, CRect& rc1, CRect& rc2,CString& clr);
	VOID ChangePixel(CDC* pChessDC, CRect& rc);
	CString GetCurDir();
	BOOL IsBoardColor(COLORREF clr);
	vector<ChessPixel> m_vecChessPixel;
	void LoadChessPixel(LPCSTR sValue);


	BOOL FindChess(CDC* pChessDC, ChessPixel& st, CRect& rc2, CString& clr,int x,int y);
};
