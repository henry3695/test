#pragma once
class Chess
{
public:
	Chess();
	~Chess();

	CString m_sVaule;
	CString m_sYanSe;
	POINT m_pt;
	BOOL m_bVisible;
};

