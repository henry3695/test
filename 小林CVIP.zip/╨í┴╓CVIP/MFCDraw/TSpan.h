#pragma once
class TSpan
{
private:
	DWORD m_dtTick;
public:
	TSpan();
	~TSpan();


	void  Begin();
	DWORD SpanSec();
	DWORD SpanMillSec();
};

