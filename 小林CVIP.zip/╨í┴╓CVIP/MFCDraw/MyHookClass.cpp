#include "stdafx.h"
#include "MyHookClass.h"


MyHookClass::MyHookClass()
{
	m_pfnOld = NULL;
	ZeroMemory(m_bNewBytes, 5);
	ZeroMemory(m_bOldBytes, 5);
}


MyHookClass::~MyHookClass()
{
	UnHook();
}

BOOL MyHookClass::Hook(char* szModuleName/*ģ����*/, char* szFuncName/*������*/, PROC pHookFunc/*�µĺ�����ַ*/)
{
	m_pfnOld = GetProcAddress(GetModuleHandleA(szModuleName), szFuncName);
	if (!m_pfnOld)
	{
		return FALSE;
	}

	DWORD dwNum = 0;
	ReadProcessMemory(GetCurrentProcess(), m_pfnOld, m_bOldBytes, 6, &dwNum);

	void *hookedFunAddress = &pHookFunc;
	BYTE patch[6] = { 0 };
	patch[0] = 0x68;
	memcpy(patch + 1, hookedFunAddress, 4);
	patch[5] = 0xc3;


	SIZE_T bytesWritten;
	// patch the MessageBoxA
	WriteProcessMemory(GetCurrentProcess(), (LPVOID)m_pfnOld, patch, sizeof(patch), &bytesWritten);

	memcpy(m_bNewBytes, patch, 6);

	return TRUE;
}

void MyHookClass::UnHook()
{
	if (m_pfnOld != NULL)
	{
		DWORD dwNum = 0;
		WriteProcessMemory(GetCurrentProcess(), m_pfnOld, m_bOldBytes, 6, &dwNum);
	}
}

bool MyHookClass::ReHook()
{
	if (m_pfnOld != NULL)
	{
		DWORD dwNum = 0;

		WriteProcessMemory(GetCurrentProcess(), m_pfnOld, m_bNewBytes, 6, &dwNum);
		return true;
	}
	return false;
}
