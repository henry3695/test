#include "stdafx.h"
#include "Chess.h"


Chess::Chess()
{
	m_bVisible=FALSE;
}


Chess::~Chess()
{
}
