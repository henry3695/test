// ContrlDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCDraw.h"
#include "ContrlDlg.h"
#include "afxdialogex.h"


// CContrlDlg �Ի���

IMPLEMENT_DYNAMIC(CContrlDlg, CDialog)

CContrlDlg::CContrlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG_CTRL, pParent), m_pMainWnd(NULL), m_pStatic1(NULL), m_pStatic2(NULL), m_pStatic3(NULL)
{

}

CContrlDlg::~CContrlDlg()
{
}

void CContrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CContrlDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_TEST, &CContrlDlg::OnBnClickedButtonTest)
	ON_BN_CLICKED(IDC_CHECK_SHOW, &CContrlDlg::OnBnClickedCheckShow)
	ON_BN_CLICKED(IDC_CHECK_NICK, &CContrlDlg::OnBnClickedCheckNick)
	ON_BN_CLICKED(IDC_BUTTON_EXIT, &CContrlDlg::OnBnClickedButtonExit)
	ON_BN_CLICKED(IDC_CHECK_FULL, &CContrlDlg::OnBnClickedCheckFull)
END_MESSAGE_MAP()


// CContrlDlg ��Ϣ��������



typedef struct tagWNDINFO
{
	DWORD dwProcessId;
	HWND hWnd;
} WNDINFO, *LPWNDINFO;
//ö�ٴ��ڹ���
BOOL CALLBACK EnumProc(HWND hWnd, LPARAM lParam)
{
	DWORD dwProcessId;
	GetWindowThreadProcessId(hWnd, &dwProcessId);
	LPWNDINFO pInfo = (LPWNDINFO)lParam;


	char szBuff[100] = { 0 };
	GetWindowText(hWnd, szBuff, 100);

	char sMsg[200] = { 0 };
	sprintf(sMsg, "DLL: 0x%x  %s", (DWORD)hWnd, szBuff);
	OutputDebugString(sMsg);

	if (CString(szBuff) == "�й�����2017")
	{
		pInfo->hWnd = hWnd;
		return FALSE;		
	}
	return TRUE;
}
//��ȡ�����ھ��
HWND GetProcessMainWnd()
{
	DWORD dwProcessId = ::GetCurrentProcessId();
	WNDINFO wi;
	wi.dwProcessId = dwProcessId;
	wi.hWnd = NULL;
	EnumWindows(EnumProc, (LPARAM)&wi);
	return wi.hWnd;
}
void CContrlDlg::OnBnClickedButtonTest()
{
	DWORD dwCurrentProcessId = GetCurrentProcessId();
	char szMsg[200] = { 0 };
	HWND hMain = GetProcessMainWnd();
	sprintf(szMsg, "DLL:%d hMain:0x%x", dwCurrentProcessId, (DWORD)hMain);
	OutputDebugString(szMsg);

	sprintf(szMsg, "QQ����2022");
	::SetWindowText(hMain, szMsg);

	/*CWnd* pMain = GetParent();
	char szMsg[200] = { 0 };

	sprintf(szMsg, "DLL:0x%x", pMain->GetSafeHwnd());
	OutputDebugString(szMsg);*/


	m_pMainWnd = FromHandle(hMain);


	 m_pStatic1 = new CWnd;
	 m_pStatic1->Create(_T("STATIC"), _T("1     2      3      4      5     6      7      8     9"), WS_CHILD | WS_VISIBLE,
		CRect(70, 120, 70+555, 120+20), m_pMainWnd, 1234);
	 m_pStatic1->SetFont(&m_cfont);


	 m_pStatic2 = new CWnd;
	 m_pStatic2->Create(_T("STATIC"), _T("��    ��     ��     ��    ��     ��     ��     ��     һ"), WS_CHILD | WS_VISIBLE,
		 CRect(65, 822, 65 + 560, 822 + 20), m_pMainWnd, 1234);
	 m_pStatic2->SetFont(&m_cfont);

	 CButton* pBtn = (CButton*)GetDlgItem(IDC_CHECK_SHOW);
	 pBtn->SetCheck(1);
	 pBtn->EnableWindow(TRUE);

	 m_pStatic3 = new CWnd;
	 m_pStatic3->Create(_T("STATIC"), _T("����֮��"), WS_CHILD | WS_VISIBLE,
		 CRect(390, 940, 390 + 160, 940 + 45), m_pMainWnd, 1234);
	 m_pStatic3->SetFont(&m_cfont);

	 pBtn = (CButton*)GetDlgItem(IDC_CHECK_NICK);
	 pBtn->SetCheck(1);
	 pBtn->EnableWindow(TRUE);


	 pBtn = (CButton*)GetDlgItem(IDC_CHECK_FULL);
	 pBtn->SetCheck(0);
	 pBtn->EnableWindow(TRUE);



	 //��1��
	 m_pMainWnd->GetClientRect(m_rectGameDlg);//��ô���Ĵ�С
}


BOOL CContrlDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cfont.CreatePointFont(150, _T("����"), NULL);
	
	LoadChessPixel("��");
	LoadChessPixel("��");
	LoadChessPixel("˧");
	LoadChessPixel("��");
	LoadChessPixel("��");
	LoadChessPixel("��");
	LoadChessPixel("��");
	LoadChessPixel("��");
	LoadChessPixel("��");
	LoadChessPixel("ʿ");
	LoadChessPixel("��");

	return TRUE;  

}

void CContrlDlg::LoadChessPixel(LPCSTR sValue)
{
	ChessPixel st;
	st.sValue = sValue;

	CString strFilePath;
	strFilePath.Format("%s\\aImg\\%s.bin", GetCurDir(), sValue);
	CFile cf;
	cf.Open(strFilePath, CFile::modeRead);
	cf.Read((void*)st.Pixels, sizeof(st.Pixels));
	cf.Close();
	
	


	for (int i = 0; i < CHESS_CX; i++)
	{
		for (int j = 0; j < CHESS_CY; j++)
		{
			if (st.Pixels[i][j] == RGB(255, 255, 255))
					continue;

			POINT pt;
			pt.x = i;
			pt.y = j;
			st.vecZM.push_back(pt);
		}
	}

	//strFilePath.Format("%s\\aImg\\%s.ZM", GetCurDir(), sValue);
	//
	//cf.Open(strFilePath, CFile::modeCreate | CFile::modeWrite);
	//cf.Write((void*)&st.vecZM[0], sizeof(POINT)*st.vecZM.size());
	//cf.Close();

	m_vecChessPixel.push_back(st);

}



void CContrlDlg::OnBnClickedCheckShow()
{
	CButton* pBtn = (CButton*)GetDlgItem(IDC_CHECK_SHOW);
	int state = pBtn->GetCheck();
	if (state == 1)
	{
		m_pStatic1->ShowWindow(SW_SHOW);
		m_pStatic2->ShowWindow(SW_SHOW);
	}
	else
	{
		m_pStatic1->ShowWindow(SW_HIDE);
		m_pStatic2->ShowWindow(SW_HIDE);
	}
}


void CContrlDlg::OnBnClickedCheckNick()
{
	CButton* pBtn = (CButton*)GetDlgItem(IDC_CHECK_NICK);
	int state = pBtn->GetCheck();
	if (state == 1)
	{
		m_pStatic3->ShowWindow(SW_SHOW);
	}
	else
	{
		m_pStatic3->ShowWindow(SW_HIDE);
	}
}


void CContrlDlg::OnBnClickedButtonExit()
{
	exit(0);
}

CString CContrlDlg::GetCurDir()
{
	char szFilePath[MAX_PATH];
	if (GetModuleFileName(NULL, szFilePath, MAX_PATH) > 0)
	{
		(*strrchr(szFilePath, '\\')) = '\0';//�����ļ������õ�·��   
	}

	return szFilePath;
}


BOOL CContrlDlg::IsBoardColor(COLORREF clr)
{
	int r = GetRValue(clr);
	int g = GetGValue(clr);
	int b = GetBValue(clr);
	if (r > 100 && g > 100 && b > 100)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}



void CContrlDlg::OnBnClickedCheckFull()
{
	TSpan t;
	t.Begin();
	CString strFilePath;

	strFilePath.Format("%s\\aImg\\config_wg.ini", GetCurDir());	
	AddMessage(strFilePath);

	POINT pt1, pt2, pt3, pt4;

	int left,top,cx,cy, spanx[8],spany[9];
	cx = CHESS_CX;
	cy = CHESS_CY;


	int cmpray;
	left = ::GetPrivateProfileInt("POS", "left", 0, strFilePath);
	top = ::GetPrivateProfileInt("POS", "top", 0, strFilePath);




	cmpray = ::GetPrivateProfileInt("CMP", "cmpray", 0, strFilePath);


	pt1.x= ::GetPrivateProfileInt("CMP", "a1", 0, strFilePath);
	pt1.y = ::GetPrivateProfileInt("CMP", "b1", 0, strFilePath);

	pt2.x = ::GetPrivateProfileInt("CMP", "a2", 0, strFilePath);
	pt2.y = ::GetPrivateProfileInt("CMP", "b2", 0, strFilePath);

	pt3.x = ::GetPrivateProfileInt("CMP", "a3", 0, strFilePath);
	pt3.y = ::GetPrivateProfileInt("CMP", "b3", 0, strFilePath);

	pt4.x = ::GetPrivateProfileInt("CMP", "a4", 0, strFilePath);
	pt4.y = ::GetPrivateProfileInt("CMP", "b4", 0, strFilePath);

	for (int i = 0; i < 8; i++)
	{
		char szKey[10] = {0};
		sprintf(szKey, "spanx%d", i);
		spanx[i] = ::GetPrivateProfileInt("POS", szKey, 0, strFilePath);
	}
	for (int i = 0; i < 9; i++)
	{
		char szKey[10] = { 0 };
		sprintf(szKey, "spany%d", i);
		spany[i] = ::GetPrivateProfileInt("POS", szKey, 0, strFilePath);
	}

	CFont font;
	//font.CreateFont(40, 40, 0, 0, FW_BLACK, FALSE, FALSE,
	//	FALSE, GB2312_CHARSET, OUT_DEFAULT_PRECIS,
	//	CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
	//	FIXED_PITCH | FF_MODERN, "����");

	font.CreateFont(160, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,

		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY,

		DEFAULT_PITCH | FF_DONTCARE, "����");


	font.DeleteObject();


	CDC* pDC = GetDC();

	HWND hWnd = m_pMainWnd->GetSafeHwnd();	
	RECT rect;
	::GetClientRect(hWnd, &rect);

	int nWidht = rect.right - rect.left;
	int nHeight = rect.bottom - rect.top;

	SetWindowPos(m_pMainWnd, 0, 0, nWidht, nHeight + 30, SWP_NOMOVE);

	HDC hSrcDC = ::GetDC(hWnd);
	ASSERT(hSrcDC);
	HDC hMemDC = ::CreateCompatibleDC(hSrcDC);
	ASSERT(hMemDC);
	HBITMAP hBitmap = ::CreateCompatibleBitmap(hSrcDC, nWidht, nHeight);
	ASSERT(hBitmap);
	HBITMAP hOldBitmap = (HBITMAP)::SelectObject(hMemDC, hBitmap);
	::BitBlt(hMemDC, 0, 0, nWidht, nHeight, hSrcDC, 0, 0, SRCCOPY);

	CDC* pChessDC = CDC::FromHandle(hMemDC);
	CBrush brush;
	brush.CreateSolidBrush(RGB(255, 0, 0));


	pChessDC->SetBkMode(TRANSPARENT);

	CFont* oldfont = pChessDC->SelectObject(&font);

	CRect rc(left, top, left + cx , top + cy);

	CRect rc_chress[10][10];
	for (int i=0;i<9;i++)
	{
		rc.top = top;
		rc.bottom = top + cy;
		for (int j = 0; j < 10; j++)
		{
			CString s;
			s.Format("(%d,%d)", i, j);
			
			pChessDC->TextOut(rc.left, rc.top-20, s);
			pChessDC->FrameRect(&rc, &brush);
			rc_chress[i][j] = rc;
			//ChangePixel(pChessDC, rc);
			if (j < 9)
			{
				rc.top += (spany[j] + cy);
				rc.bottom += (spany[j] + cy);
			}
		}
		if (i < 8)
		{
			rc.left += (spanx[i] + cx);
			rc.right += (spanx[i] + cx);
		}	
	}
	

#if 0
	COLORREF clr;
	


	COLORREF Che[CHESS_CX][CHESS_CY] = {0};

	strFilePath.Format("%s\\aImg\\1.bin", GetCurDir());

	CFile cf;
	BOOL b = cf.Open(strFilePath, CFile::modeRead);
	if (b == FALSE)
	{
		if (pt1.x >= 0 && pt1.y >= 0)
		{
			rc = rc_chress[pt1.x][pt1.y];
			for (int i = 0; i < cx; i++)
			{
				for (int j = 0; j < cy; j++)
				{
					if (IsBoardColor(Che[i][j]) == TRUE)
						continue;

					clr = pChessDC->GetPixel(rc.left + i, rc.top + j);
					if (IsBoardColor(clr) == TRUE)
					{
						Che[i][j] = RGB(255, 255, 255);
					}
				}
			}
		}
		else
		{
			AfxMessageBox("pt1 �������");
		}
	}
	else
	{
		cf.Read(Che, sizeof(Che));
		cf.Close();
	}

	if (pt1.x >= 0 && pt1.y >= 0)
	{
		rc = rc_chress[pt1.x][pt1.y];
		for (int i = 0; i < cx; i++)
		{
			for (int j = 0; j < cy; j++)
			{
				if (IsBoardColor(Che[i][j]) == TRUE)
					continue;

				clr = pChessDC->GetPixel(rc.left + i, rc.top + j);
				if (IsBoardColor(clr) == TRUE)
				{
					Che[i][j] = RGB(255, 255, 255);
				}
			}
		}
	}

	if (pt2.x >= 0 && pt2.y >= 0)
	{
		rc = rc_chress[pt2.x][pt2.y];
		for (int i = 0; i < cx; i++)
		{
			for (int j = 0; j < cy; j++)
			{
				if (IsBoardColor(Che[i][j]) == TRUE)
					continue;

				clr = pChessDC->GetPixel(rc.left + i, rc.top + j);
				if (IsBoardColor(clr) == TRUE)
				{
					Che[i][j] = RGB(255, 255, 255);
				}
			}
		}
	}

	if (pt3.x >= 0 && pt3.y >= 0)
	{
		rc = rc_chress[pt3.x][pt3.y];
		for (int i = 0; i < cx; i++)
		{
			for (int j = 0; j < cy; j++)
			{
				if (IsBoardColor(Che[i][j]) == TRUE)
					continue;

				clr = pChessDC->GetPixel(rc.left + i, rc.top + j);
				if (IsBoardColor(clr) == TRUE)
				{
					Che[i][j] = RGB(255, 255, 255);
				}
			}
		}
	}

	if (pt4.x >= 0 && pt4.y >= 0)
	{
		rc = rc_chress[pt4.x][pt4.y];
		for (int i = 0; i < cx; i++)
		{
			for (int j = 0; j < cy; j++)
			{
				if (IsBoardColor(Che[i][j]) == TRUE)
					continue;

				clr = pChessDC->GetPixel(rc.left + i, rc.top + j);
				if (IsBoardColor(clr) == TRUE)
				{
					Che[i][j] = RGB(255, 255, 255);
				}
			}
		}
	}
	for (int i = 0; i < cx; i++)
	{
		for (int j = 0; j < cy; j++)
		{
			pChessDC->SetPixel(i, j, Che[i][j]);
		}
	}

	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			CString clr;
			BOOL b = CompareArea(pChessDC, CRect(0, 0, cx, cy), rc_chress[i][j], clr);
			if (b)
			{
				CString sMsg;
				sMsg.Format("(%d,%d) ƥ�� %s", i, j, clr);
				AddMessage(sMsg);

				CString s;
				s.Format("%sƥ��", clr);
				pChessDC->TextOut(rc_chress[i][j].left, rc_chress[i][j].top + 20, s);
			}
		}
	}

	
	cf.Open(strFilePath, CFile::modeCreate | CFile::modeWrite);
	cf.Write((void*)&Che, sizeof(Che));
	cf.Close();
#endif


#if 1
	//����ɨ��
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			for (int k = 0; k < m_vecChessPixel.size(); k++)
			{
				CString clr;
				BOOL b = FindChess(pChessDC, m_vecChessPixel[k], rc_chress[i][j], clr,i,j);
				if (b)
				{
					CString sMsg;
					sMsg.Format("(%d,%d) ƥ�� %s", i, j, clr);
					AddMessage(sMsg);

					CString s;
					s.Format("(%d,%d)%s%s", i, j, clr, m_vecChessPixel[k].sValue);
					pChessDC->TextOut(rc_chress[i][j].left, rc_chress[i][j].top-20, s);
				}
			}
		}
	}
#endif
	pChessDC->SelectObject(oldfont);
	font.DeleteObject();


	pDC->BitBlt(0, 30, nWidht, nHeight, CDC::FromHandle(hMemDC), 0, 0, SRCCOPY);


	::SelectObject(hMemDC, hOldBitmap);
	::DeleteObject(hBitmap);
	::DeleteDC(hMemDC);
	::ReleaseDC(hWnd, hSrcDC);
	ReleaseDC(pDC);

	CString sMsg;
	sMsg.Format("t=%d",t.SpanMillSec());
	AddMessage(sMsg);	
}

BOOL CContrlDlg::FindChess(CDC* pChessDC, ChessPixel& st, CRect& rc2, CString& clr, int x, int y)
{
	int rCount = 0;
	int bCount = 0;

	if (st.sValue == "��" || st.sValue == "��")
	{
		if( ( 
			(x=2 && y==0) ||
			(x = 0 && y == 2) ||
			(x = 2 && y == 4) ||
			(x = 4 && y == 2) ||
			(x = 6 && y == 4) ||
			(x = 8 && y == 2) ||
			(x = 6 && y == 0) ||
			(x = 0 && y == 7) ||
			(x = 2 && y == 5) ||
			(x = 2 && y == 9) ||
			(x = 4 && y == 7) ||
			(x = 6 && y == 5) ||
			(x = 6 && y == 9) ||
			(x = 8 && y == 7) )==FALSE)
		{
			return FALSE;
		}
	}
	else if (st.sValue=="ʿ" && st.sValue=="��")
	{
		if ((
			(x = 3 && y == 0) ||
			(x = 3 && y == 2) ||
			(x = 5 && y == 0) ||
			(x = 5 && y == 2) ||

			(x = 3 && y == 7) ||
			(x = 3 && y == 9) ||
			(x = 5 && y == 7) ||
			(x = 5 && y == 9)) == FALSE)
		{
			return FALSE;
		}
	}
	else if (st.sValue == "��" && st.sValue == "˧")
	{
		if ((
			(x = 3 && y == 0) ||
			(x = 3 && y == 2) ||
			(x = 5 && y == 0) ||
			(x = 5 && y == 2) ||

			(x = 4 && y == 0) ||
			(x = 4 && y == 2) ||
			(x = 3 && y == 1) ||
			(x = 5 && y == 1) ||

			(x = 3 && y == 7) ||
			(x = 3 && y == 9) ||
			(x = 5 && y == 7) ||
			(x = 5 && y == 9)||

			(x = 4 && y == 7) ||
			(x = 4 && y == 9) ||
			(x = 3 && y == 8) ||
			(x = 5 && y == 8) 		
			
			) == FALSE)
		{
			return FALSE;
		}
	}

	vector<POINT>& vecZM = st.vecZM;
	for (int t=0;t<vecZM.size();t++)
	{
		POINT& pt = vecZM[t];
		COLORREF r2 = pChessDC->GetPixel(rc2.left + pt.x, rc2.top + pt.y );
		if (GetRValue(r2) > 100)
		{
			rCount++;
		}
		else
		{
			bCount++;
		}
		if (IsBoardColor(r2) == TRUE)
		{
			//AddMessage("is not same ");
			return FALSE;
		}
	}

	if (rCount > bCount)
	{
		clr = "��";
	}
	else
	{
		clr = "��";
	}
	return TRUE;
#if 0
	COLORREF (&Pixels)[CHESS_CX][CHESS_CY] = st.Pixels;

	int cx = rc2.Width();
	int cy = rc2.Height();
	int rCount = 0;
	int bCount = 0;
	for (int i = 0; i < cx; i++)
	{
		for (int j = 0; j < cy; j++)
		{
			COLORREF r1 = Pixels[i][j];
			COLORREF r2 = pChessDC->GetPixel(rc2.left + i, rc2.top + j);
			if (IsBoardColor(r1) == TRUE)
				continue;

			if (GetRValue(r2) > 100)
			{
				rCount++;
			}
			else
			{
				bCount++;
			}

			if (IsBoardColor(r2) == TRUE)
			{
				//AddMessage("is not same ");
				return FALSE;
			}
		}
	}
	if (rCount > bCount)
	{
		clr = "��";
	}
	else
	{
		clr = "��";
	}
	//AddMessage("is same ");
	return TRUE;
#endif
}


BOOL CContrlDlg::CompareArea(CDC* pChessDC, CRect& rc1, CRect& rc2, CString& clr)
{
	if (rc1.Width() != rc2.Width())
	{
		//AddMessage("width is not same");
		return FALSE;
	}

	if (rc1.Height() != rc2.Height())
	{
		//AddMessage("height is not same");
		return FALSE;
	}


	int cx = rc1.Width();
	int cy = rc1.Height();
	int rCount = 0;
	int bCount = 0;
	for (int i=0;i<cx;i++)
	{
		for (int j=0;j<cy;j++)
		{
			COLORREF r1 = pChessDC->GetPixel(rc1.left + i, rc1.top + j);
			COLORREF r2 = pChessDC->GetPixel(rc2.left + i, rc2.top + j);
			if (IsBoardColor(r1) == TRUE)
				continue;

			if (GetRValue(r2) > 100)
			{
				rCount++;
			}
			else
			{
				bCount++;
			}		

			if (IsBoardColor(r2)==TRUE)
			{
				//AddMessage("is not same ");
				return FALSE;
			}		
		}
	}	
	if (rCount>bCount)
	{
		clr = "��";
	}
	else
	{
		clr = "��";
	}

	//AddMessage("is same ");
	return TRUE;
}

VOID CContrlDlg::ChangePixel(CDC* pChessDC, CRect& rc)
{
	int cx = rc.Width();
	int cy = rc.Height();

	for (int i = 0; i < cx; i++)
	{
		for (int j = 0; j < cy; j++)
		{
			CPoint pt(rc.left + i, rc.top + j);
			COLORREF color = pChessDC->GetPixel(pt);
			int r = GetRValue(color);
			int g = GetGValue(color);
			int b = GetBValue(color);
			if (r > 100 && g > 100 && b>100)
			{
				pChessDC->SetPixel(pt, RGB(255, 255, 255));
			}
		}
	}
}
