// MFCDraw.cpp : ���� DLL �ĳ�ʼ�����̡�
//

#include "stdafx.h"
#include "MFCDraw.h"
#include "MyHookClass.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//
//TODO:  ����� DLL ����� MFC DLL �Ƕ�̬���ӵģ�
//		��Ӵ� DLL �������κε���
//		MFC �ĺ������뽫 AFX_MANAGE_STATE �����ӵ�
//		�ú�������ǰ�档
//
//		����: 
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// �˴�Ϊ��ͨ������
//		}
//
//		�˺������κ� MFC ����
//		������ÿ��������ʮ����Ҫ��  ����ζ��
//		��������Ϊ�����еĵ�һ�����
//		���֣������������ж������������
//		������Ϊ���ǵĹ��캯���������� MFC
//		DLL ���á�
//
//		�й�������ϸ��Ϣ��
//		����� MFC ����˵�� 33 �� 58��
//

// CMFCDrawApp

BEGIN_MESSAGE_MAP(CMFCDrawApp, CWinApp)
END_MESSAGE_MAP()


// CMFCDrawApp ����

CMFCDrawApp::CMFCDrawApp()
{
	// TODO:  �ڴ˴����ӹ�����룬
	// ��������Ҫ�ĳ�ʼ�������� InitInstance ��
}


// Ψһ��һ�� CMFCDrawApp ����

CMFCDrawApp theApp;


// CMFCDrawApp ��ʼ��
#include "ContrlDlg.h"



FARPROC GetSystemMetricsAddress = NULL;
SIZE_T bytesWritten = 0;
char GetSystemMetricsOriginalBytes[6] = {};
bool bInit = false;

int __stdcall HookedGetSystemMetrics(int nIndex) {

	// print intercepted values from the MessageBoxA function
	//std::cout << "Ohai from the hooked function\n";
	//std::cout << "Text: " << (LPCSTR)lpText << "\nCaption: " << (LPCSTR)lpCaption << std::endl;

	char szMsg[1024] = { 0 };
	sprintf(szMsg, "msg:Ohai from the hooked function nIndex=%d\n", nIndex);
	OutputDebugString(szMsg);

	/*
	sprintf(szMsg, "msg: %s Caption: %s ", (LPCSTR)lpText, (LPCSTR)lpCaption);
	OutputDebugString(szMsg);*/

	// unpatch MessageBoxA
	//WriteProcessMemory(GetCurrentProcess(), (LPVOID)messageBoxAddress, messageBoxOriginalBytes, sizeof(messageBoxOriginalBytes), &bytesWritten);

	// call the original MessageBoxA
	//return MessageBoxA(NULL, lpText, lpCaption, uType);

	if (SM_CXFULLSCREEN == nIndex || SM_CXSCREEN==nIndex)
	{
		strcpy(szMsg, "msg:1024\n");
		OutputDebugString(szMsg);
		return 1024;
	}
	else if (SM_CYFULLSCREEN == nIndex || SM_CYSCREEN==nIndex)
	{
		strcpy(szMsg, "msg:800\n");
		OutputDebugString(szMsg);
		return 800;
	}

	return 1;
}


MyHookClass g_MsgHookRecv;
MyHookClass g_MsgHookSend;

MyHookClass g_MsgHookCreate;
MyHookClass g_MsgHookMe;


#include "TSpan.h"
TSpan g_Tspan;

#include "vector"
using namespace std;
//Unicode����תΪ���ֽڱ���  
bool UnicodeToMB(vector<char>& pmb, const wchar_t* pun, int uLen)
{
	// convert an widechar string to Multibyte   
	int MBLen = WideCharToMultiByte(CP_ACP, 0, pun, uLen, NULL, 0, NULL, NULL);
	if (MBLen <= 0)
	{
		return false;
	}
	pmb.resize(MBLen);
	int nRtn = WideCharToMultiByte(CP_ACP, 0, pun, uLen, &*pmb.begin(), MBLen, NULL, NULL);

	if (nRtn != MBLen)
	{
		pmb.clear();
		return false;
	}
	return true;
}



#include<WS2tcpip.h>
int __stdcall recv1(SOCKET s, char* buf, int len, int flags) {
	g_MsgHookRecv.UnHook();
	int n = recv(s, buf, len, flags);

	struct sockaddr_in sa = {0};
	int lens = sizeof(sa);
	getpeername(s, (struct sockaddr *)&sa, &lens);


	char ip[20] = { 0 };
	inet_ntop(AF_INET, (void*)&sa.sin_addr, ip, 16);

	//CString sMsg,sTmp;
	//sMsg.Format("msg:rev %s:%d len:%d ", ip, ntohs(sa.sin_port), n);
	//for (int i = 0; i < n; i++)
	//{
	//	sTmp.Format("0x%02X ", (BYTE)buf[i]);
	//	sMsg += sTmp;
	//}
	//OutputDebugString(sMsg);

	g_MsgHookRecv.ReHook();
	return n;
}

int __stdcall  send1(IN SOCKET s, IN const char FAR * buf, IN int len, IN int flags)
{
	g_MsgHookSend.UnHook();
	int n = send(s, buf, len, flags);

	struct sockaddr_in sa = { 0 };
	int lens = sizeof(sa);
	getpeername(s, (struct sockaddr *)&sa, &lens);


	char ip[20] = { 0 };
	inet_ntop(AF_INET, (void*)&sa.sin_addr, ip, 16);

	//CString sMsg, sTmp;
	//sMsg.Format("msg:send %s:%d len:%d ", ip, ntohs(sa.sin_port), n);
	//for (int i = 0; i < n; i++)
	//{
	//	sTmp.Format("0x%02X ", (BYTE)buf[i]);
	//	sMsg += sTmp;
	//}
	//OutputDebugString(sMsg);
	g_MsgHookSend.ReHook();
	return n;
}

int __stdcall GetSystemMetrics_ME(_In_ int nIndex)
{
	g_MsgHookMe.UnHook();

	int n = GetSystemMetrics(nIndex);

	g_MsgHookMe.ReHook();

	CString sMsg;
	sMsg.Format("msg:nIndex=%d n=%d", nIndex,n);
	OutputDebugString(sMsg);

	return n;
}


HWND __stdcall CreateWindowExW_ME(
	_In_ DWORD dwExStyle,
	_In_opt_ LPCWSTR lpClassName,
	_In_opt_ LPCWSTR lpWindowName,
	_In_ DWORD dwStyle,
	_In_ int X,
	_In_ int Y,
	_In_ int nWidth,
	_In_ int nHeight,
	_In_opt_ HWND hWndParent,
	_In_opt_ HMENU hMenu,
	_In_opt_ HINSTANCE hInstance,
	_In_opt_ LPVOID lpParam)
{
	g_MsgHookCreate.UnHook();

	vector<char> ClassName;
	UnicodeToMB(ClassName, lpClassName, wcslen(lpClassName));
	ClassName.push_back(0);

	vector<char> WindowName;
	UnicodeToMB(WindowName, lpWindowName, wcslen(lpClassName));
	WindowName.push_back(0);

	CString sMsg;
	sMsg.Format("%s", &WindowName[0]);

	if (sMsg.Find("�й�����")!=-1)
	{
		/*	nHeight = nHeight * 15/10;
			nWidth = nWidth * 15 / 10;*/
	}

	//if (nHeight == 1043)
	//{
	//	nHeight = 1200;
	//}
	

	HWND h = CreateWindowExW(dwExStyle,
		lpClassName,
		lpWindowName,
		dwStyle,
		X,
		Y,
		nWidth,
		nHeight,
		hWndParent,
		hMenu,
		hInstance,
		lpParam);
	g_MsgHookCreate.ReHook();

	


	
	sMsg.Format("%s,%s X=%d,Y=%d,nWidth=%d,nHeight=%d", &ClassName[0],&WindowName[0], X, Y, nWidth, nHeight);

	OutputDebugString("msg:hook create "+ sMsg);
	return h;
}


BOOL __stdcall SetWindowPos_ME(_In_ HWND hWnd, _In_opt_ HWND hWndInsertAfter, _In_ int X, _In_ int Y, _In_ int cx, _In_ int cy, _In_ UINT uFlags)
{
	g_MsgHookMe.UnHook();

	//if (cy == 1043)
	//{
	//	cy = 1200;
	//}
	BOOL b = SetWindowPos(hWnd, hWndInsertAfter, X, Y, cx, cy, uFlags);

	g_MsgHookMe.ReHook();

	CString sMsg;
	sMsg.Format("msg:X=%d Y=%d cx=%d cy=%d", X, Y, cx, cy);
	OutputDebugString(sMsg);

	return b;
}

int __stdcall DrawTextW_ME(
	HDC     hdc,
	LPCWSTR lpchText,
	int     cchText,
	LPRECT  lprc,
	UINT    format
)
{
	g_MsgHookMe.UnHook();

	int n = DrawTextW(hdc, lpchText, cchText, lprc, format);

	/*wchar_t* pw = L"this is test";
	DrawTextW(hdc, pw, wcslen(pw), CRect(0,0,100,30), format);*/

	//2�����ڲ�ˢ��

	//if (g_Tspan.SpanMillSec() > 2000)
	{
		//CDC *pDC = CDC::FromHandle(hdc);
		//pDC->FillSolidRect(CRect(0,0,100,100), RGB(255, 0, 0));
		g_Tspan.Begin();
		OutputDebugString("msg:������");

		SetTextColor(hdc, RGB(255, 0, 0));
		MoveToEx(hdc, 0, 0, nullptr);
		LineTo(hdc, 500, 500);

	}


	
	g_MsgHookMe.ReHook();


	vector<char> Text;
	UnicodeToMB(Text, lpchText, wcslen(lpchText));
	Text.push_back(0);


	//CString sMsg;
	//sMsg.Format("msg:%d,%d %s ,hdc=0x%x", lprc->left, lprc->top, &Text[0], hdc);
	//OutputDebugString(sMsg);

	//::TextOut(hdc, 100, 100, "abc123", 6);


	return n;
}


BOOL __stdcall BitBlt_ME(
	HDC   hdc,
	int   x,
	int   y,
	int   cx,
	int   cy,
	HDC   hdcSrc,
	int   x1,
	int   y1,
	DWORD rop
)
{
	g_MsgHookMe.UnHook();
	BOOL b = BitBlt(hdc, x, y, cx, cy, hdcSrc, x1, y1, rop);
	g_MsgHookMe.ReHook();

	CString sMsg;
	sMsg.Format("msg:x=%d,y=%d,cx=%d,cy=%d,x1=%d,y1=%d,rop=%d,hdc=0x%x", x, y, cx, cy, x1, y1, rop,hdc);
	OutputDebugString(sMsg);


	//CDC* pDC = m_pMainWnd->GetDC();
	//COLORREF oldBkColor = pDC->GetBkColor();
	//pDC->FillSolidRect(CRect(0, 0, 50, 50), RGB(255, 0, 0));

	//pDC->TextOut(100, 100, "this is test");
	//pDC->SetBkColor(oldBkColor);
	//m_pMainWnd->ReleaseDC(pDC);

	return b;
}



BOOL CMFCDrawApp::InitInstance()
{
	CWinApp::InitInstance();

	
	//if (false == bInit)
	//{
	//	//::MessageBoxA(NULL, "hi", "hi", MB_OK);

	//	HINSTANCE library = LoadLibraryA("user32.dll");
	//	SIZE_T bytesRead = 0;

	//	// get address of the MessageBox function in memory
	//	GetSystemMetricsAddress = GetProcAddress(library, "GetSystemMetrics");

	//	// save the first 6 bytes of the original MessageBoxA function - will need for unhooking
	//	ReadProcessMemory(GetCurrentProcess(), GetSystemMetricsAddress, GetSystemMetricsOriginalBytes, 6, &bytesRead);

	//	// create a patch "push <address of new MessageBoxA); ret"
	//	void *hookedMessageBoxAddress = &HookedGetSystemMetrics;
	//	char patch[6] = { 0 };
	//	memcpy_s(patch, 1, "\x68", 1);
	//	memcpy_s(patch + 1, 4, &hookedMessageBoxAddress, 4);
	//	memcpy_s(patch + 5, 1, "\xC3", 1);

	//	// patch the MessageBoxA
	//	WriteProcessMemory(GetCurrentProcess(), (LPVOID)GetSystemMetricsAddress, patch, sizeof(patch), &bytesWritten);
	//	bInit = true;
	//}

	//if (FALSE == g_MsgHookRecv.Hook("WS2_32.dll", "recv", (PROC)recv1)) {
	//	OutputDebugString("msg:recv error\n");
	//}

	//if (FALSE == g_MsgHookSend.Hook("WS2_32.dll", "send", (PROC)send1)) {
	//	OutputDebugString("msg:send error\n");
	//}

	//if (FALSE == g_MsgHookCreate.Hook("user32.dll", "CreateWindowExW", (PROC)CreateWindowExW_ME))
	//{
	//	OutputDebugString("msg:CreateWindowExW error");
	//}

	//if (FALSE == g_MsgHookMe.Hook("user32.dll", "SetWindowPos", (PROC)SetWindowPos_ME))
	//{
	//	OutputDebugString("msg:SetWindowPos error");
	//}


	//g_Tspan.Begin();
	//if (FALSE == g_MsgHookMe.Hook("user32.dll", "DrawTextW", (PROC)DrawTextW_ME))
	//{
	//	OutputDebugString("msg:DrawTextW error");
	//}

	//if (FALSE == g_MsgHookMe.Hook("GDI32.dll", "BitBlt", (PROC)BitBlt_ME))
	//{
	//	OutputDebugString("msg:BitBlt error");
	//}





	
	OutputDebugString("msg:hook mfcdraw.dll");
	
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CContrlDlg *pTD = new CContrlDlg();
	pTD->Create(IDD_DIALOG_CTRL); //����һ����ģ̬�Ի���  
	pTD->ShowWindow(SW_SHOWNORMAL);

	return TRUE;
}
