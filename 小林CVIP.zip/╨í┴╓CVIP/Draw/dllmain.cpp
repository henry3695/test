// dllmain.cpp : ���� DLL Ӧ�ó������ڵ㡣
#include "stdafx.h"
#include "stdio.h"
extern "C" __declspec(dllexport) int MyFunc(long parm1)
{
	OutputDebugString("DLL:MyFunc");
	return 0;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)// �ص�����
{
	DWORD dwCurProcessId = *((DWORD*)lParam);
	DWORD dwProcessId = 0;

	GetWindowThreadProcessId(hwnd, &dwProcessId);
	if (dwProcessId == dwCurProcessId && GetParent(hwnd) == NULL)
	{
		*((HWND *)lParam) = hwnd;

		char szBuff[50] = { 0 };
		GetWindowText(hwnd, szBuff,50);

		char sMsg[100] = { 0 };
		sprintf(sMsg, "DLL: %x  %s", (DWORD)hwnd, szBuff);
		OutputDebugString(sMsg);
		return FALSE;
	}

	return TRUE;
}


typedef struct tagWNDINFO
{
	DWORD dwProcessId;
	HWND hWnd;
} WNDINFO, *LPWNDINFO;
//ö�ٴ��ڹ���
BOOL CALLBACK EnumProc(HWND hWnd, LPARAM lParam)
{
	DWORD dwProcessId;
	GetWindowThreadProcessId(hWnd, &dwProcessId);
	LPWNDINFO pInfo = (LPWNDINFO)lParam;


	char szBuff[100] = { 0 };
	GetWindowText(hWnd, szBuff, 100);

	char sMsg[200] = { 0 };
	sprintf(sMsg, "DLL: 0x%x  %s", (DWORD)hWnd, szBuff);
	OutputDebugString(sMsg);

	if (dwProcessId == pInfo->dwProcessId)
	{
		pInfo->hWnd = hWnd;
		return FALSE;
	}
	return TRUE;
}
//��ȡ�����ھ��
HWND GetProcessMainWnd()
{
	DWORD dwProcessId = ::GetCurrentProcessId();
	WNDINFO wi;
	wi.dwProcessId = dwProcessId;
	wi.hWnd = NULL;
	EnumWindows(EnumProc, (LPARAM)&wi);
	return wi.hWnd;
}

#include "assert.h"
using namespace std;
#include <iostream>
#include <thread>

HWND g_hMain = NULL;
HDC  g_hDC = NULL;
HINSTANCE g_hIntance=NULL;

DWORD WINAPI clientthread(LPVOID lpparam)
{
	while (g_hMain == NULL)
	{
		Sleep(5000);
		DWORD dwCurrentProcessId = GetCurrentProcessId();
		char szMsg[200] = { 0 };
		HWND hMain = GetProcessMainWnd();
		sprintf(szMsg, "DLL:%d hMain:0x%x", dwCurrentProcessId, (DWORD)hMain);
		OutputDebugString(szMsg);
		g_hMain = hMain;
	}
	
	char szMsg[50] = { 0 };
	sprintf(szMsg, "QQ����2022");
	SetWindowText(g_hMain, szMsg);

	HWND hsub;
	/*hsub = CreateWindow(
		"BUTTON",   // predefined class 
		"OK",       // button text 
		WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // styles  
		10,         // starting x position 
		10,         // starting y position 
		100,        // button width 
		100,        // button height 
		g_hMain,       // parent window 
		NULL,       // No menu 
		g_hIntance,
		NULL);      // pointer not needed */


	hsub= CreateWindow("STATIC", "Some static text",
		WS_CHILD | WS_VISIBLE | SS_OWNERDRAW,
		10,         // starting x position 
		10,         // starting y position 
		100,        // button width 
		100,        // button height 
		g_hMain,       // parent window 
		NULL,       // No menu 
		NULL,
		NULL);      // pointer not needed */



	sprintf(szMsg, "DLL: hsub:0x%x", hsub);
	OutputDebugString(szMsg);

	/*if (g_hMain != NULL)
	{
		g_hDC = GetDC(g_hMain);

		char szMsg[50] = { 0 };
		sprintf(szMsg, "һ�����������߰˾�");
		while (g_hDC)
		{
			Sleep(50);
			::TextOut(g_hDC,0, 0, szMsg,strlen(szMsg));
		}
	}*/
	return 0;
}



BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	{
		g_hIntance = (HINSTANCE)hModule;

		assert(0);
		OutputDebugString("DLL:DLL_PROCESS_ATTACH");


		int num = 1;
		HANDLE hthread;
		DWORD dwthreadid;

		hthread = CreateThread(NULL, 0, clientthread, (LPVOID)num, 0, &dwthreadid);
		if (hthread == NULL)
		{
			printf("fail55\n");
		}
		WaitForSingleObject(hthread, 2000);
		CloseHandle(hthread);
	}

		break;
	case DLL_THREAD_ATTACH:
	{
		OutputDebugString("DLL:DLL_THREAD_ATTACH");

		
	}
		break;
	case DLL_THREAD_DETACH:
		OutputDebugString("DLL:DLL_THREAD_DETACH");
		break;
	case DLL_PROCESS_DETACH:
		OutputDebugString("DLL:DLL_PROCESS_DETACH");
		break;
	}
	return TRUE;
}

