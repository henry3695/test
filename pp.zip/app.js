const https = require('https');
const fs = require('fs');
const express = require("express");
const path = require("path")
const app = express();

const jwt = require('jsonwebtoken');


app.use(express.json())

app.use(function (req, res, next) {
    //设置允许跨域的域名，*代表允许任意域名跨域
    res.header("Access-Control-Allow-Origin", "*");
    //允许的header类型
    res.header("Access-Control-Allow-Headers", "content-type");
    //跨域允许的请求方式
    res.header("Access-Control-Allow-Methods", "DELETE,PUT,POST,GET,OPTIONS");
    if (req.method == "OPTIONS") res.sendStatus(200); //让options尝试请求快速结束
    else next();
});
app.use(express.static(path.join(__dirname,"./public")))


//  拦截 /api 下的所有请求 验证 token
app.use('/user', authMiddleware);
app.use("/user", require("./router/user"))
app.use("/login", require("./router/login"))
app.use("/top", require("./router/top"))

const port = 8443;

app.get("/", (req, res) => {
    res.send("hello");
})


const options = {
  key: fs.readFileSync(path.resolve(__dirname, 'ssl/lol.cc8.lol.key')),
  cert: fs.readFileSync(path.resolve(__dirname, 'ssl/lol.cc8.lol.cer')),
  ca: fs.readFileSync('ssl/lol.cc8.lol.cer'),
};

/*app.listen(port, () => {
    console.log(`服务端运行成功:http://localhost:${port}`)
})*/

https.createServer(options, app).listen(8443, () => {
  console.log('HTTPS server is running on https://lol.cc8.lol:8443');
});


// 生成 Token
function generateToken(user) {
  const payload = { userId: user.id, username: user.username };
  const secret = '[40:25] *MUO]908'; // 请勿将密钥硬编码
  const options = { expiresIn: '1h' };

  return jwt.sign(payload, secret, options);
}

// 验证 Token
function verifyToken(token) {
  const secret = '[40:25] *MUO]908';
  try {
    const decoded = jwt.verify(token, secret);
    return decoded;
  } catch (error) {
    return null;
  }
}

// 中间件
function authMiddleware(req, res, next) {
  const token = req.headers['authorization'];
  console.log(token)
  if (token == null) return res.sendStatus(401);

  const decoded = verifyToken(token);
  if (!decoded) return res.sendStatus(403);

  req.user = decoded;
  next();
}