const express = require("express");
const { db } = require("../db/dbutils")
var router = express.Router();

router.get("/list", (req, res) => {
    db.all("SELECT *,(SingleScore+DoubleScore) AS totalScore from `user`  ORDER BY id desc", (err, rows) => {
        res.send(rows)
    })
})
module.exports = router;
