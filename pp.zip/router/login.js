const express = require("express");
const { db } = require("../db/dbutils")
const jwt = require('jsonwebtoken');
var router = express.Router();

function generateToken(user) {
    const payload = { userId: user.id, username: user.username };
    const secret = '[40:25] *MUO]908'; // 请勿将密钥硬编码
    const options = { expiresIn: '1h' };
  
    return jwt.sign(payload, secret, options);
  }
router.get("/", (req, res) => {
   res.send("login")
})

router.post("/", (req, res) => {
    const { username, userpwd } = req.body
    console.log(username,userpwd)
    // 示例用法
    authenticateUser(username,userpwd)
    .then(user => {
        console.log('登录成功：', user);
        res.send({
            code: 200,
            message: "登录成功!",
            token:generateToken(user)
        })
    })
    .catch(error => {
        console.error('登录失败：', error.message);
        res.send({
            code: 500,
            message: "登录失败!"
        })
    });
 })


 // 登录验证函数
async function authenticateUser(username, password) {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM `user` WHERE username = ?', [username], (err, row) => {
        if (err) {
          console.error(err);
          reject(new Error('数据库查询错误'));
        }
  
        if (!row) {
          reject(new Error('用户不存在'));
        } else {
          // 验证密码（这里使用简单的字符串比较，实际应用中应该使用加密算法）
          if (row.userpwd === password) {
            resolve(row); // 登录成功，返回用户信息
          } else {
            reject(new Error('密码错误'));
          }
        }
      });
    });
  }

module.exports = router;