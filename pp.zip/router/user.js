const express = require("express");
const { db } = require("../db/dbutils")
var router = express.Router();


router.get("/list", (req, res) => {
    db.all("SELECT *,(SingleScore+DoubleScore) AS totalScore from `user`  ORDER BY id desc", (err, rows) => {
        res.send(rows)
    })
})

router.delete("/delete", (req, res) => {
    const deleteId = req.query.id;
    db.all("delete from `user` where `id` = ? ", [deleteId], (err, rows) => {
        if (err == null) {
            res.send({
                code: 200,
                message: "删除成功"
            })
        } else {
            res.send({
                code: 500,
                message: "删除失败"
            })
        }
    })
})

router.post("/add", (req, res) => {
    let user = req.body;
    console.log(user)
    db.run("INSERT INTO `user`(`username`,`userpwd`,`SingleScore`,`DoubleScore`,`create_time`) VALUES(?,?,?,?,?)", 
    [ user.username, user.userpwd,0,0, new Date().getTime()], (err, rows) => {
        if (err == null) {
            res.send({
                code: 200,
                message: "添加成功"
            })
        } else {
            res.send({
                code: 500,
                message: "添加失败"
            })
        }
    })
})


router.post("/update", (req, res) => {
    const editId = req.query.id
    let user = req.body
    console.log(editId)
    console.log(user)
    const sql = `UPDATE user SET userpwd = ?,create_time=? WHERE id = ?`;
    // 执行 SQL 查询
    db.run(sql, [user.userpwd,new Date().getTime(),editId], function(err) {
        if (err) {         
            res.send({
                code: 500,
                message: `修改密码失败${ err.message}`
            })
            return
        }
        
        // 返回修改的行数
        console.log(`密码已修改，受影响的行数: ${this.changes}`);
        res.send({
            code: 200,
            message: `密码已修改，受影响的行数: ${this.changes}`
        })
    });
})


module.exports = router;
